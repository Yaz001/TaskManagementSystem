﻿using System;
using System.Net.Http;
using System.Text;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace TaskManagementSystemApp
{
    public partial class RegisterForm : Form
    {
        private readonly HttpClient _httpClient;

        public RegisterForm()
        {
            InitializeComponent();
        }

        private async void btnRegSubmit_Click(object sender, EventArgs e)
        {
            var registerData = new
            {
                Username = txtRegUsername.Text,
                Password = txtRegPassword.Text,
                Role = txtRole.Text
        };

            if (string.IsNullOrEmpty(registerData.Username) || string.IsNullOrEmpty(registerData.Password))
            {
                MessageBox.Show("Username and password are required.");
                return;
            }

            try
            {
                var response = await ApiHelper1.PostAsync("https://localhost:7139/api/auth/register", registerData);

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Registration successful.");
                    // Clear the fields so user can enter new credentials
                    txtRegUsername.Clear();
                    txtRegPassword.Clear();
                    txtRole.Clear();


                    // Optionally, set the focus back to the username field
                    txtRegUsername.Focus();
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    MessageBox.Show($"Failed to register. Reason: {errorContent}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            // Show the LoginForm
            var loginForm = new LoginForm();
            loginForm.Show();

            this.Close();
        }
    }
}
