﻿using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Text;
using System.Windows.Forms;

namespace TaskManagementSystemApp
{
    public partial class LoginForm : Form
    {
        
        //private readonly string _baseUrl = "https://localhost:7139/api/auth/login"; 

        public LoginForm()
        {
            InitializeComponent();
        }

        private async void btnLogin_Click(object sender, EventArgs e)
        {
            var loginData = new
            {
                Username = txtUsername.Text,
                Password = txtPassword.Text
            };

            var response = await ApiHelper1.PostAsync("https://localhost:7139/api/auth/login", loginData);

            if (response.IsSuccessStatusCode)
            {
                var jsonResponse = await response.Content.ReadAsStringAsync();
                dynamic result = JsonConvert.DeserializeObject(jsonResponse);
                string token = result.token;

                // Store the JWT for future requests
                ApiHelper1.SetBearerToken(token);

                // Open the task management form
                var taskManagementForm = new TaskManagementForm(token);
                taskManagementForm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid login credentials.");
            }
        }
    


    private void btnRegister_Click(object sender, EventArgs e)
        {
            var registerForm = new RegisterForm();
            registerForm.Show();
            this.Hide();
        }

    }
}
