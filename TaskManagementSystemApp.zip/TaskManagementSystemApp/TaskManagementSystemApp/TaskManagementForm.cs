﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace TaskManagementSystemApp
{
    public partial class TaskManagementForm : Form
    {
        private string _token;

        public TaskManagementForm(string token)
        {
            InitializeComponent();
            _token = token;

            // Ensure the JWT token is set for API requests
            ApiHelper1.SetBearerToken(_token);


            // Prevent the user from selecting past dates in the DateTimePicker
            dateTimePickerDueDate.MinDate = DateTime.Today;

            // Wire up the SelectionChanged event
            dataGridViewTasks.SelectionChanged += dataGridViewTasks_SelectionChanged;
        
            // Load tasks when the form is initialized
            LoadTasks();


        }


        private async Task LoadTasks()
        {
            try
            {
                var response = await ApiHelper1.GetAsync("https://localhost:7139/api/tasks");

                if (response.IsSuccessStatusCode)
                {
                    var jsonResponse = await response.Content.ReadAsStringAsync();
                    var tasks = JsonConvert.DeserializeObject<List<TaskItem>>(jsonResponse);
                    dataGridViewTasks.DataSource = tasks; // Bind tasks to DataGridView
                }
                else
                {
                    MessageBox.Show("Failed to load tasks.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }


        // Get the selected task ID from the DataGridView
        private int GetSelectedTaskId()
        {
            if (dataGridViewTasks.SelectedRows.Count > 0)
            {
                return Convert.ToInt32(dataGridViewTasks.SelectedRows[0].Cells[0].Value); // Assuming Task ID is in the first column
            }
            else
            {
                MessageBox.Show("Please select a task.");
                throw new Exception("No task selected.");
            }
        }



        // Populate the fields with the selected task's data for editing
        private void tasksDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewTasks.SelectedRows.Count > 0)
            {
                var selectedRow = dataGridViewTasks.SelectedRows[0];
                txtTaskTitle.Text = selectedRow.Cells["Title"].Value.ToString();
                txtTaskDescription.Text = selectedRow.Cells["Description"].Value.ToString();
                dateTimePickerDueDate.Value = Convert.ToDateTime(selectedRow.Cells["DueDate"].Value);
                //chkIsCompleted.Checked = selectedRow.Cells["IsCompleted"].Value.ToString(); // Error
            }
        }




        private void dataGridViewTasks_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewTasks.SelectedRows.Count > 0)
            {
                var selectedRow = dataGridViewTasks.SelectedRows[0];

                // Populate text boxes
                txtTaskTitle.Text = selectedRow.Cells["Title"].Value.ToString();
                txtTaskDescription.Text = selectedRow.Cells["Description"].Value.ToString();

                // Handle DueDate
                DateTime dueDate;
                if (DateTime.TryParse(selectedRow.Cells["DueDate"].Value.ToString(), out dueDate))
                {
                    if (dueDate >= dateTimePickerDueDate.MinDate && dueDate <= dateTimePickerDueDate.MaxDate)
                    {
                        dateTimePickerDueDate.Value = dueDate;
                    }
                    else
                    {
                        dateTimePickerDueDate.Value = DateTime.Today;
                        MessageBox.Show($"The due date {dueDate} is outside the allowable range. Setting to today's date.");
                    }
                }
                else
                {
                    dateTimePickerDueDate.Value = DateTime.Today;
                    MessageBox.Show("Invalid date format. Setting to today's date.");
                }

                // Set CheckBox for IsCompleted
                bool isCompleted;
                if (TryParseIsCompleted(selectedRow.Cells["IsCompleted"].Value.ToString(), out isCompleted))
                {
                    chkIsCompleted.Checked = isCompleted;
                }
                else
                {
                    chkIsCompleted.Checked = false;
                }
            }
        }







        private async void btnAddTask_Click(object sender, EventArgs e)
        {
            var task = new
            {
                Title = txtTaskTitle.Text,
                Description = txtTaskDescription.Text,
                DueDate = dateTimePickerDueDate.Value, // Parse the date correctly
                IsCompleted = chkIsCompleted.Checked
            };

            var response = await ApiHelper1.PostAsync("https://localhost:7139/api/tasks", task);

            if (response.IsSuccessStatusCode)
            {
                MessageBox.Show("Task added successfully.");
                LoadTasks(); // Refresh task list
            }
            else
            {
                MessageBox.Show("Failed to add task.");
            }
        }



        private async void btnUpdateTask_Click(object sender, EventArgs e)
        {
            try
            {
                int taskId = GetSelectedTaskId(); // Get the selected task's ID

                var updatedTask = new
                {
                    Title = txtTaskTitle.Text,
                    Description = txtTaskDescription.Text,
                    DueDate = dateTimePickerDueDate.Value, // DueDate as string
                    IsCompleted = chkIsCompleted.Checked// IsCompleted as check box
                };

                var response = await ApiHelper1.PutAsync($"https://localhost:7139/api/tasks/{taskId}", updatedTask);

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Task updated successfully.");
                    await LoadTasks(); // Refresh task list after updating
                }
                else
                {
                    MessageBox.Show("Failed to update task.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private async void btnDeleteTask_Click(object sender, EventArgs e)
        {
            try
            {
                // Get the selected task ID from the DataGridView
                int taskId = GetSelectedTaskId(); // This method retrieves the task ID

                // Send a DELETE request to the API
                var response = await ApiHelper1.DeleteAsync($"https://localhost:7139/api/tasks/{taskId}");

                // Check if the task was successfully deleted
                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Task deleted successfully.");
                    await LoadTasks(); // Refresh the task list after deletion
                }
                else
                {
                    MessageBox.Show("Failed to delete the task.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }



        private bool TryParseDueDate(out DateTime dueDate)
        {
            return DateTime.TryParse(dateTimePickerDueDate.Text, out dueDate);
        }


        private bool TryParseIsCompleted(string isCompletedString, out bool isCompleted)
        {
            // Try to parse the string as a boolean
            return bool.TryParse(isCompletedString, out isCompleted);
        }


        private async void btnUpdateTask_Click_1(object sender, EventArgs e)
        {
            try
            {
                // Get the selected task's ID
                int taskId = GetSelectedTaskId(); // Use the GetSelectedTaskId() method

                // Get the selected row
                var selectedRow = dataGridViewTasks.SelectedRows[0];

                // Parse the DueDate and IsCompleted values
                DateTime dueDate;
                if (!TryParseDueDate(out dueDate))
                {
                    MessageBox.Show("Invalid Due Date format. Please enter a valid date.");
                    return;
                }

                bool isCompleted;
                if (bool.TryParse(selectedRow.Cells["IsCompleted"].Value.ToString(), out isCompleted))
                {
                    chkIsCompleted.Checked = isCompleted; // Check or uncheck the CheckBox
                }
                else
                {
                    chkIsCompleted.Checked = false; // If parsing fails, default to unchecked
                }

                // Create an updated task object from the input fields
                var updatedTask = new
                {
                    Title = txtTaskTitle.Text,
                    Description = txtTaskDescription.Text,
                    DueDate = dateTimePickerDueDate.Value, // Parsed DueDate
                    IsCompleted = isCompleted // Parsed IsCompleted
                };

                // Log or print the updatedTask object to check the values before sending
                var updatedTaskJson = JsonConvert.SerializeObject(updatedTask);
                MessageBox.Show($"Updating task with data: {updatedTaskJson}");

                // Send a PUT request to update the task
                var response = await ApiHelper1.PutAsync($"https://localhost:7139/api/tasks/{taskId}", updatedTask);

                // Check if the update was successful
                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Task updated successfully.");
                    await LoadTasks(); // Refresh the task list after updating
                }
                else
                {
                    // Show detailed response for better debugging
                    var errorContent = await response.Content.ReadAsStringAsync();
                    MessageBox.Show($"Failed to update the task. Response: {errorContent}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }


        private void btnBack_Click(object sender, EventArgs e)
        {
            // Show the LoginForm
            var loginForm = new LoginForm();
            loginForm.Show();

            // Close the TaskManagementForm
            this.Close();
        }

    }




    public class TaskItem
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public bool IsCompleted { get; set; }
    }
}

