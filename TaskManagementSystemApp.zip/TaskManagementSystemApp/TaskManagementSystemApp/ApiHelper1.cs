﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace TaskManagementSystemApp
{


    public class ApiHelper1
    {
        private static readonly HttpClient client = new HttpClient();

        public static async Task<HttpResponseMessage> PostAsync(string url, object content)
        {
            var json = JsonConvert.SerializeObject(content);
            var stringContent = new StringContent(json, Encoding.UTF8, "application/json");
            return await client.PostAsync(url, stringContent);
        }

        public static async Task<HttpResponseMessage> GetAsync(string url)
        {
            return await client.GetAsync(url);
        }

        public static async Task<HttpResponseMessage> PutAsync(string url, object content)
        {
            var json = JsonConvert.SerializeObject(content);
            var stringContent = new StringContent(json, Encoding.UTF8, "application/json");
            return await client.PutAsync(url, stringContent);
        }

        public static async Task<HttpResponseMessage> DeleteAsync(string url)
        {
            return await client.DeleteAsync(url);
        }

        public static void SetBearerToken(string token)
        {
            client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        }
    }

}
