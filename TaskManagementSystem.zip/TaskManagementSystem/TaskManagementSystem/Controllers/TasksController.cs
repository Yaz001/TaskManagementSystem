﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using TaskManagementSystem.Models;

namespace TaskManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class TasksController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ILogger<TasksController> _logger;

        public TasksController(AppDbContext context, ILogger<TasksController> logger)
        {
            _context = context;
            _logger = logger;
        }

        //This method extracts the current user's UserId from the JWT claims
        private int GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
            if (userIdClaim == null)
            {
                throw new Exception("User ID not found in token.");
            }
            return int.Parse(userIdClaim.Value);
        }

        


        // GET: api/Tasks
        [HttpGet]
        public ActionResult<IEnumerable<TaskItem>> GetTasks()
        {
            var userId = GetCurrentUserId();
            var tasks = _context.Tasks
                .Where(t => t.UserId == userId)
                .ToList(); // Use synchronous method ToList
            return Ok(tasks);
        }

        // POST: api/Tasks
        [HttpPost]
        public IActionResult CreateTask([FromBody] TaskItem task)
        {
            if (task == null || string.IsNullOrEmpty(task.Title))
            {
                return BadRequest("Task title is required.");
            }

            task.UserId = GetCurrentUserId();  // Ensure UserId is being set

            _context.Tasks.Add(task);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetTasks), new { id = task.Id }, task);
        }








        // GET: api/Tasks/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetTaskById(int id)
        {
            var task = await _context.Tasks.SingleOrDefaultAsync(t => t.Id == id && t.UserId == GetCurrentUserId());
            if (task == null)
                return NotFound();

            return Ok(task);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTask(int id)
        {
            var task = await _context.Tasks.SingleOrDefaultAsync(t => t.Id == id && t.UserId == GetCurrentUserId());
            if (task == null)
                return NotFound();

            _context.Tasks.Remove(task);
            await _context.SaveChangesAsync(); // Use async save changes
            return NoContent();
        }

        // PUT: api/Tasks/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTask(int id, [FromBody] TaskItem task)
        {
            if (task == null || !ModelState.IsValid)
                return BadRequest("Invalid task data.");

            var existingTask = await _context.Tasks.SingleOrDefaultAsync(t => t.Id == id && t.UserId == GetCurrentUserId());
            if (existingTask == null)
                return NotFound();

            existingTask.Title = task.Title;
            existingTask.Description = task.Description;
            existingTask.DueDate = task.DueDate;
            existingTask.IsCompleted = task.IsCompleted;

            await _context.SaveChangesAsync();
            return Ok(existingTask);
        }

    }
}
