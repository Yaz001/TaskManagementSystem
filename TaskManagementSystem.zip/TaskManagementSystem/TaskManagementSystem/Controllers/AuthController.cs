﻿using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using TaskManagementSystem.Models;
using TaskManagementSystem.Services;


namespace TaskManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly JwtService _jwtService;
        private readonly ILogger<AuthController> _logger;

        public AuthController(AppDbContext context, JwtService jwtService, ILogger<AuthController> logger)
        {
            _context = context;
            _jwtService = jwtService;
            _logger = logger;
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginDto loginDto)
        {
            if (string.IsNullOrEmpty(loginDto.Username) || string.IsNullOrEmpty(loginDto.Password))
                return BadRequest("Username and password are required.");

            var user = _context.Users.SingleOrDefault(u => u.Username == loginDto.Username);

            if (user == null || !VerifyPasswordHash(loginDto.Password, user.Password))
                return Unauthorized(new { message = "Invalid username or password." });

            // Pass UserId when generating the JWT
            var token = _jwtService.GenerateToken(user.Username, user.Role, user.Id);
            return Ok(new { token });
        }


        [HttpPost("register")]
        public IActionResult Register([FromBody] User registerUser)
        {
            // Ensure the username and password are not null or empty
            if (string.IsNullOrEmpty(registerUser.Username) || string.IsNullOrEmpty(registerUser.Password))
                return BadRequest("Username and password are required.");

            // Check if the username already exists
            if (_context.Users.Any(u => u.Username == registerUser.Username))
                return Conflict("Username already exists.");

            // Assign default role if not provided
            if (string.IsNullOrEmpty(registerUser.Role))
                registerUser.Role = "User";  // Assign default role

            // Hash the password before saving (using a secure hashing method)
            registerUser.Password = HashPassword(registerUser.Password);

            try
            {
                // Add the user to the database
                _context.Users.Add(registerUser);
                _context.SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                // Log the exception details
                _logger.LogError(ex, "An error occurred while saving the user to the database. Username: {Username}", registerUser.Username);
                return StatusCode(500, "Internal server error. Please try again later.");
            }

            return Ok(new { message = "Registration successful" });
        }



        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                return Convert.ToBase64String(sha256.ComputeHash(Encoding.UTF8.GetBytes(password)));
            }
        }

        private bool VerifyPasswordHash(string? password, string storedHash)
        {
            return HashPassword(password) == storedHash;
        }



    }
}
