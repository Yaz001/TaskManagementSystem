﻿using System.ComponentModel.DataAnnotations;

namespace TaskManagementSystem.Models
{
    public class TasksDB
    
    {

            [Required]
            public string Title { get; set; }

            [Required]
            public string Description { get; set; }

            [Required]
            public string DueDate { get; set; } // Change to string

            public bool IsCompleted { get; set; }
        }
    }
    



